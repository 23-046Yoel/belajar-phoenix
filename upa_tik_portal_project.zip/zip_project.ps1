$zipPath = "upa_tik_portal_project.zip"
if (Test-Path $zipPath) { Remove-Item $zipPath }
$exclude = @("_build", "deps", ".git", ".vscode", "upa_tik_portal_project.zip", "belajar-phoenix-main.zip", "node_modules")
$items = Get-ChildItem -Path . -Exclude $exclude -Force
$items | Compress-Archive -DestinationPath $zipPath -Force
Write-Host "Zip created successfully: $zipPath"
